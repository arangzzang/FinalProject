package com.project.jobnom.welcome.model.service;

import java.util.List;

import com.project.jobnom.welcome.model.vo.FAQ;

public interface WelcomeService {
	
	List<FAQ> welcomFAQView();

}
